package com.cdac;

import java.util.Scanner;

public class Student 
{

	public static void main(String[] args) 
	{
	
		int sid=1001;
		String name="nsnathan";
		int mark=30;
		String sub="python";
		float per=89.0f;
		char grade='A';
		boolean feespaid = true ;
		
		System.out.println(sid);
		System.out.println(name);
		System.out.println(mark);
		System.out.println(sub);
		System.out.println(per);
		System.out.println(grade);
		System.out.println(feespaid);
		
		
		
		
		
		
	}
	
}
