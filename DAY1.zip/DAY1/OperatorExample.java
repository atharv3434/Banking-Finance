package com.cdac;

public class OperatorExample 
{

	public static void main(String[] args) 
	{
	
//	    int a = 0;
//	    
//	    System.out.println(a);
//	    System.out.println(a++);
//	    System.out.println(++a);
	    
//	    int c = 0;
//	    
//	    int res = c + c++ + ++c;
//	    System.out.println(res);
	    
//		int num = 11;
//		
//		if(num%2==0)
//		{
//			System.out.println("even");
//		}else
//			System.out.println("odd");
		
		
		
//		int a = 10;
//		int b = 20;
//		
//		if(a>b)
//		{
//			System.out.println(a +" is max");
//		}else
//		{
//			System.out.println(b + "  is max");
//		}
		
//		String qualification = "B.E";
//		float per = 69.9f;
//		
//		if((qualification =="B.E" || qualification == "M.SC") && per >= 60)
//		{
//			System.out.println("eligible for bda");
//		}else
//			System.out.println("not eligible for bda");
		
		
//		  int unit = 200;
//		  
//		  float amount;
//		  
//		  if(unit<=100)
//		  {   amount = unit*1;
//		  
//			  System.out.println();
//		  }else if(unit<=200)
//		  {
//			  amount = unit*2;
//		  }else if(unit<=300)
//		  {
//			  amount = unit*3;
//		  }else
//			  amount = unit *4;
		
		
		
		
	    
	    
		
	}
		
}
