package com.cdac;

public class DatatypesVariableExample
{
		
	
	public static void main(String[] args) 
	{
	  		  int productid=1001;
			  String pname="dell";
			  float price = 30000;
			 float discount = price*0.02f;
			 System.out.println(discount);
			 
			 
			 
	
	}
	
}
