package com.cdac;

public class Student
{

	int sid;
	String name;
	int mark;
	static String cname;
	
	public Student(int id,String na,int ma)
	{
		
		sid = id;
		name = na;
		mark = ma;
		
		
	}
	
	public static void readCname()
	{
		cname = "AI";
		
	}
	public void displayStudent()
	{
		System.out.println(sid+name+mark+cname);
	}
	
	
	
	
}
