package com.cdac;

public class StudentMain 
{

	public static void main(String[] args) {
		
		Student s1 = new Student(1001,"shan",30);
		Student.readCname();
		s1.displayStudent();
		Student s2 = new Student(1002,"raj",40);
		s2.displayStudent();
		
		Student s3 = new Student(1003,"kumar",50);
		s3.displayStudent();
	} 
	
}
