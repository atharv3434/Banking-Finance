package com.cdac;

public class Emp 
{
     int empno;
	 String name;
     float sal;
     
     Emp(int eno,String na,float sa)
     {
    	 empno = eno;
    	 name = na;
    	 sal = sa;
     }
     
     void displayEmp()
     {
    	 System.out.println(empno+name+sal);
     }
	
}
