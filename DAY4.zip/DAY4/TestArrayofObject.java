package com.cdac;

public class TestArrayofObject 
{

	public static void main(String[] args) 
	{
	
		
		Emp[] e = new Emp[3];
		
		e[0] = new Emp(1001,"shan",3000);
		e[1] = new Emp(1002,"raj",4000);
		e[2] = new Emp(1003,"siju",5000);
		
//		e[0].displayEmp();
//		e[1].displayEmp();
//		e[2].displayEmp();
		
		for(int i=0;i<3;i++)
		{
			e[i].displayEmp();
		}
		
	} 
	
}
