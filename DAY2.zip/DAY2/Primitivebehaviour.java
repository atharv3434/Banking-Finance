package cdac;

public class Primitivebehaviour 
{
	public static void changeValues(int a, int b)
	{
		a = 20;
		b = 10;
		
	}
	public static void main(String[] args) 
	{
	
		int a = 10;
		int b = 20;
		System.out.println("before");
		System.out.println(a +" "+ b);
		
		changeValues(a,b);
		System.out.println("after");
		System.out.println(a +" "+ b);
		
	}

	
	
	
}
