package cdac;

import java.util.Scanner;

public class ArrayExample1 
{

	public static void main(String[] args) 
	{
	//integer array
		
		int[] num = new int[5];
		
//		num[0] = 10;
//		num[1] = 20;
//		num[2] = 30;
//		num[3] = 40;
//		num[4] = 50;
		
		
	//	int[] num = {10,20,30,40,50};
		
		 Scanner s = new Scanner(System.in);
		 
//		for(int i=0;i<=4;i++)
//		{
//          
//			num[i] = s.nextInt();
//		}
		
		
//		for(int i=0;i<=4;i++)
//		{
//
//		System.out.println(num[i]);
//		}

//		for(int n:num)
//		{
//			System.out.println(n);
//		}
		
	//string array
		
	//	 String[] name = new String[5];
		 
//		String[] subject = {"c++","java","python","dbt"};
//		
//		for(String ele:subject)
//		{
//			System.out.println(ele);
//		}
//		
	}
	
	
}
