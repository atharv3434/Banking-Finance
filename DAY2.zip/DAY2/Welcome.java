package cdac;

public class Welcome 
{

	
	public static void main(String[] args) 
	{
	
		TestStatic.greet("nsnathan");
		
		
	}
	
}
