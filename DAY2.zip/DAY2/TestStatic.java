package cdac;

public class TestStatic
{

	public static void greet(String name)
	{
		System.out.println("welcome " +name);
	}
	
	
}
