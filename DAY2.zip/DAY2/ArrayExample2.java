package cdac;

public class ArrayExample2 
{

	public static void main(String[] args) 
	{
	
		int[] num =ArrayManagement.createArrayElement();
		
		ArrayManagement.displayArrayElement(num);
		int sum = ArrayManagement.sumofArrayElement(num);
		System.out.println("sum of element is " + sum);
		
	}
	
	
}
