package cdac;

public class ArrayManagement
{

	public static int[] createArrayElement()
	{
		System.out.println("create");
		
		int[] num = {10,20,30,40,50};
		
		return num;
	}

	public static void displayArrayElement(int[] num)
	{
		System.out.println("display");
		for(int n:num)
		{
			System.out.println(n);
		}
		
	}

	public static int sumofArrayElement(int[] num) 
	{
		int sum =0;
		System.out.println("sum");
		
		for(int n:num)
		{
			sum = sum +n;
		}
		
		return sum;
		
	}
	
	
}
