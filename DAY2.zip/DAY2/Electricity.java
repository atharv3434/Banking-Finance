package cdac;

public class Electricity
{

	 public  int findAmount(int unit)
     {
		
 		int amount =0;
 		
 		if(unit<100)
 		{
 			amount = unit*1;
 		}else if(unit<200)
 		{
 			amount = 100+(unit-100)*2;
 		}else if(unit<300)
 		{
 			amount = 100+200+(unit-200)*3;
 		}else
 			amount = 100+200+300+(unit-300)*4;
 		
 		
 		return amount;
 		
 		
   	  
   	  
     }
	
}
