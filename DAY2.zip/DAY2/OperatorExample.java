package cdac;

public class OperatorExample 
{

	
public static void main(String[] args) 
{

	int x =15;
	int y = 12;

	if(x>10 || y++>10)
	{
	   x++;
	}
	else
		y++;
	
	System.out.println(x+y);

}	
}
