package cdac;

import java.util.Scanner;

public class ControlStatements
{
     
	
	
	public static void main(String[] args) 
	{
		 
		 Electricity e = new Electricity();
		 
		 Scanner s = new Scanner(System.in);
		 System.out.println("enter the details");
		 int unit = s.nextInt();
		 String name = s.next();
		 int houseno = s.nextInt();
		 
		 
		 
		 int amt =e.findAmount(unit);
		System.out.println(name);
		System.out.println(houseno);
		
		System.out.println("unit = "+unit +"   amount = "+amt);
		
	}
	
	
}
