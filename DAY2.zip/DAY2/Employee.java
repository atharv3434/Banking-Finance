package cdac;

public class Employee
{

	
	public void CalculateSalary()
	{
		int basesal = 20000;
		int da = 2000;
		int hra = 4000;
		int sal = basesal +da+hra;
		System.out.println(sal);
	}
	
	
}
