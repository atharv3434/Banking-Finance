package cdac;

public class Nonprimitivebehaviour 
{

	public static void changeValues(int[] num)
	{
		num[2]=100;
		
	}
	
	
	public static void main(String[] args) 
	{
	
		int[] num = {10,20,30,40,50};
		
		System.out.println("before");
		
		for(int n:num)
		{
			System.out.println(n);
		}
		
		
		changeValues(num);
		
		
		System.out.println("after");
		
			
		for(int n:num)
		{
			System.out.println(n);
		}
	} 
	
	
	
	
}
