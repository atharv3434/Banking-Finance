package cdac;





public class NonStataicMethodExample 
{

	public static void main(String[] args) 
	{
		Employee e= new Employee(); 
		
		
		e.CalculateSalary();
		
		
	}
	
	
}
